#pragma once
#ifndef RESISTOR_H
#define RESISTOR_H

#include "Component.h"

class Resistor : public Component {
public:
	Resistor(double resistance);
};

#endif
