#pragma once
#ifndef SERIAL_H
#define SERIAL_H

#include <vector>
#include "Component.h"

class Serial : public Component {
private:
	std::vector<Component*> components;

public:
	// Add a component to the serial circuit
	void addComponent(Component* component);

	// Calculate the total resistance of the serial circuit
	double calculateResistance();
};

#endif
