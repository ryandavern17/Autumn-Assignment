#pragma once
#include "Serial.h"

void Serial::addComponent(Component* component) {
	components.push_back(component);
}

double Serial::calculateResistance() {
	double totalResistance = 0;
	for (Component* component : components) {
		totalResistance += component->getResistance();
	}
	return totalResistance;
}
