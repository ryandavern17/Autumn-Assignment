#pragma once
#include <iostream>
#include "Resistor.h"
#include "Serial.h"
#include "Parallel.h"

int main() {
	//Circuit 1 - Parallel
	Resistor r1(150); // 150 ohms resistor
	Resistor r2(250); // 250 ohms resistor
	Parallel parallelCircuit;
	parallelCircuit.addComponent(&r1);
	parallelCircuit.addComponent(&r2);

	std::cout << "Sample Parallel Circuit Resistance: " << parallelCircuit.calculateResistance() << " ohms\n";

	//Circuit 2 - Serial
	Resistor r3(150); //150 ohms resistor
	Serial serialCircuit;
	serialCircuit.addComponent(&r3);
	serialCircuit.addComponent(&parallelCircuit);

	std::cout << "Sample Serial Circuit Resistance: " << serialCircuit.calculateResistance() << " ohms\n";

	//Circuit 3 - Combined
	Resistor r4(300); //300 ohms resistor
	Parallel parallelCircuit2;
	parallelCircuit2.addComponent(&r3);
	parallelCircuit2.addComponent(&r4);

	Serial combinedCircuit;
	combinedCircuit.addComponent(&parallelCircuit);
	combinedCircuit.addComponent(&parallelCircuit2);

	std::cout << "Sample Combined Circuit Resistance: " << combinedCircuit.calculateResistance() << " ohms\n";

	return 0;
}
