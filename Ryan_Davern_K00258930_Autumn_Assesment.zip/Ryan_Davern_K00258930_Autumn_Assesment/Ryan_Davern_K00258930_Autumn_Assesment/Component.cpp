#pragma once
#include "Component.h"

Component::Component() : resistance(0) {}

Component::~Component() {}

double Component::getResistance() const {
	return resistance;
}

void Component::setResistance(double newResistance) {
	resistance = newResistance;
}
