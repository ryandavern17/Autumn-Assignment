#pragma once
#include "Parallel.h"

void Parallel::addComponent(Component* component) {
	components.push_back(component);
}

double Parallel::calculateResistance() {
	double totalResistance = 0;
	for (Component* component : components) {
		totalResistance += 1 / component->getResistance();
	}
	return 1 / totalResistance;
}
