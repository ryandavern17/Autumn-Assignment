#pragma once
#ifndef COMPONENT_H
#define COMPONENT_H

class Component {
protected:
	double resistance;

public:
	Component();
	virtual ~Component();

	// Get the resistance of the component
	double getResistance() const;

	// Set the resistance of the component
	void setResistance(double newResistance);
};

#endif
