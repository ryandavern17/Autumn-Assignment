#pragma once
#include "Resistor.h"

Resistor::Resistor(double resistance) {
	setResistance(resistance);
}
