#pragma once
#ifndef PARALLEL_H
#define PARALLEL_H

#include <vector>
#include "Component.h"

class Parallel : public Component {
private:
	std::vector<Component*> components;

public:
	// Add a component to the parallel circuit
	void addComponent(Component* component);

	// Calculate the total resistance of the parallel circuit
	double calculateResistance();
};

#endif
